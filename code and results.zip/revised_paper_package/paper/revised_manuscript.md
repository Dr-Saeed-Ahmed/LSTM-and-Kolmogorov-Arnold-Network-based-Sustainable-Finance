# Financial Connectedness in the Sustainability-Finance Network: Multi-Framework Evidence from AI-Technology, Clean-Energy, and ESG ETFs, 2018–2026

**Abstract**

The low-carbon transition is increasingly financed through thematic exchange-traded funds (ETFs) spanning artificial-intelligence (AI) technology, clean energy, and environmental-social-governance (ESG) strategies, yet the systemic-risk linkages among these segments remain poorly quantified. This study maps the connectedness of thirteen AI/technology, clean-energy, ESG, materials, and macro assets using daily data from June 2018 to May 2026 (N = 1,997), combining the Diebold–Yilmaz variance-decomposition framework, rolling-window estimation, a time-varying-parameter VAR (TVP-VAR), a quantile VAR (QVAR), and GARCH conditional volatilities, followed by a formal out-of-sample forecasting feasibility assessment. After detecting and neutralizing eight erroneous price observations that materially distort connectedness estimates, we find that: (i) the AI/technology complex — data-infrastructure (SRVR, +45.5%), robotics (ROBT, +45.0%), and AI-equity (THNQ, +29.0%) ETFs — together with critical materials (REMX, +26.3%) are the dominant net transmitters of shocks, while clean-energy assets are the dominant net receivers (ICLN −57.9%; nuclear NLR −45.4%; green bonds GRNB −16.4%); (ii) rolling total connectedness averages 48.8%, spikes to 52.4% during the COVID-19 crash, and peaks at 58.2% in the aftermath of the 2022 energy/geopolitical shock; (iii) tail connectedness is U-shaped but asymmetric, reaching 42.1% in the bear tail versus 33.2% at the median and 36.8% in the bull tail, so diversification within sustainable portfolios erodes in extreme regimes, especially crashes; and (iv) one-step-ahead forecasting of rolling connectedness is dominated by a naive persistence benchmark (out-of-sample R² ≈ 0.98–0.99): both a two-layer LSTM and an LSTM–Kolmogorov–Arnold-Network hybrid obtain significantly negative out-of-sample R² and are outperformed by persistence at the 1% level (Diebold–Mariano tests), a cautionary result for the growing practice of applying deep learning to heavily smoothed connectedness targets. The findings provide a reproducible, quantified map of how financial stress propagates through the markets that finance the energy transition, and establish that AI-market instability is a first-order transition-financing risk.

**Keywords:** sustainable finance; financial connectedness; Diebold–Yilmaz; TVP-VAR; quantile VAR; systemic risk; clean energy; artificial intelligence; forecast evaluation

---

## 1. Introduction

The transition to a low-carbon economy is increasingly intermediated by capital markets [1,2]. Since 2018, thematic exchange-traded funds (ETFs) have channeled investment toward artificial-intelligence (AI) technology, clean and alternative energy, and environmental, social, and governance (ESG) strategies [3,4]. These instruments have grown large enough that shocks originating in one sustainability-related segment can propagate to others, with direct consequences for the stability of the capital base that finances decarbonization.

The relevance of this question has grown with the emergence of the AI–energy nexus. The rapid diffusion of generative-AI workloads has raised electricity demand from data centers [5], creating a direct physical and financial channel between AI-equity performance and the clean-energy markets expected to supply that power. When AI-technology valuations rise, the associated capital flows and energy demand can pressure clean-energy assets; when they fall, the same linkage can transmit stress back. Understanding the direction, magnitude, time variation, and tail behavior of these spillovers is therefore both a sustainability question and a financial-stability question [6].

A large connectedness literature, built on the Diebold–Yilmaz (DY) spillover index [7,8] and its time-varying [9] and quantile-based [10] extensions, documents that spillovers among energy, technology, and green assets are directional, time-varying, and tail-sensitive. Three gaps remain. First, the AI/technology, clean-energy, ESG, materials, and macro segments have rarely been mapped as one integrated sustainability-finance network; most studies examine pairs or small subsets [11,12]. Second, empirical results in this literature are sensitive to data hygiene and estimator calibration, yet data-cleaning and estimator-stability checks are seldom reported — we show below that a handful of erroneous price observations can double a measured connectedness peak. Third, a recent stream applies deep learning to forecast connectedness measures [13,14], but rarely benchmarks against the naive persistence forecast, which is nearly optimal when the target is a long rolling-window statistic.

This paper addresses all three gaps with a single, fully reproducible pipeline. Our contributions are:

1. **A cleaned, verified network map.** We document and neutralize eight bad price ticks (including an impossible −109.9% daily return) in a widely used ETF dataset, and show they were responsible for the spurious connectedness readings in the original analysis (a rolling total-connectedness peak of 77.9% that disappears after cleaning). On the cleaned 13-asset system, the AI/technology complex (SRVR, ROBT, THNQ) and critical materials (REMX) are persistent net transmitters, while the clean-energy complex (ICLN, NLR, GRNB) is the persistent net receiver.
2. **Time-varying and tail evidence with stability checks.** Rolling-window DY (200-day) is complemented by a TVP-VAR with forgetting factors; we show the forgetting-factor filter is under-determined for 13 variables (351 coefficients per step) and report it transparently with a λ-sensitivity table, using the stable six-primary-asset TVP-VAR for dynamic inference. A QVAR at five quantiles establishes an asymmetric U-shaped tail structure.
3. **A forecasting feasibility assessment.** We evaluate one-step-ahead forecasts of rolling connectedness targets from persistence, AR(1), Ridge, a two-layer LSTM, and an LSTM–KAN hybrid under a strict chronological split with leakage-free standardization and Diebold–Mariano tests. Persistence attains out-of-sample R² ≈ 0.98–0.99; both deep models obtain negative R² and are significantly worse than persistence. We argue this negative result is informative for the literature: for near-unit-root rolling targets, deep-learning claims require a persistence benchmark to be interpretable.

The remainder of the paper is organized as follows. Section 2 reviews the literature. Section 3 describes data, cleaning, and methods. Section 4 reports results. Section 5 discusses economic interpretation, implications, and limitations. Section 6 concludes.

## 2. Literature Review

### 2.1. Connectedness and systemic risk in sustainable finance

Variance-decomposition-based connectedness measures [7,8] are the workhorse of empirical systemic-risk research and are increasingly applied to sustainability-relevant markets. For clean energy and technology, Ferrer et al. [15] document time- and frequency-varying connectedness between renewable-energy stocks and crude oil; Reboredo [16] and Le et al. [17] show that green bonds co-move with financial markets in ways that erode diversification during turbulence; Babalos et al. [18] link clean-energy ETF herding to climate risks. Closest to our setting, Raggad and Bouri [11] find that AI assets transmit shocks to clean/dirty energy markets at the extremes, and Khan et al. [12] report quantile time–frequency spillovers among AI, clean energy, and traditional assets. These studies typically examine small asset sets; the integrated AI/technology–clean-energy–ESG–materials–macro network remains unmapped, and the transmitter/receiver hierarchy within it unquantified.

Methodologically, the time-varying-parameter VAR of Antonakakis et al. [9] and the quantile VAR of Ando et al. [10] address, respectively, regime evolution and tail dependence; recent applications trace time-varying financial-stress contagion across trade-war and geopolitical episodes [32]. We adopt both, but add two safeguards that are rare in this literature: explicit data-error auditing, and a formal stability analysis of the forgetting-factor TVP-VAR as a function of system size.

### 2.2. Machine learning for spillover forecasting

Recurrent neural networks have been applied to forecast risk spillovers across sectors [13] and stock markets [14], and volatility-informed hybrids combine GARCH features with recurrent layers [19]. A recent innovation replaces fixed activation functions with learnable splines on network edges — Kolmogorov–Arnold Networks (KAN) [20] — which yield interpretable response curves in volatility forecasting [21,22]. This literature, however, typically benchmarks deep models against other parametric models rather than against naive persistence. Because rolling connectedness statistics are by construction near-unit-root (a 200-day window replaces only 0.5% of its sample each day), persistence is an extraordinarily strong baseline. Whether deep models clear it is, to our knowledge, untested in the spillover-forecasting literature; Section 4.5 provides that test.

## 3. Data and Methods

### 3.1. Data, asset universe, and cleaning

We use daily closing prices for thirteen assets, 4 June 2018 – 12 May 2026 (N = 1,997 trading days), spanning five sustainability-relevant categories: (1) AI/technology ETFs — THNQ (AI equity), ROBT (robotics and AI), SRVR (data infrastructure); (2) clean and alternative energy — ICLN (clean energy), GRNB (green bonds), NLR (nuclear energy); (3) ESG — SUSA, CRBN (low carbon), DSI (socially responsible); (4) critical materials — REMX (rare earths); (5) macro assets — WTI crude oil, GLD (gold), and the USD index. Log-returns are computed as r(i,t) = 100 × [ln P(i,t) − ln P(i,t−1)].

**Data cleaning.** Screening revealed eight physically implausible daily returns for equity/bond ETFs (|r| > 20%; US market-wide circuit breakers halt trading at −20%): REMX −40.3% (20 Sep 2018), −109.9%/+109.2% (17–18 Feb 2020); SUSA +69.3%/−69.5% (19–20 Feb 2020); DSI +69.3%/−69.4% (21–24 Feb 2020); THNQ −27.4% (12 May 2020). A return below −100% is impossible; the ± pairs are classic bad-print-and-reversal patterns. We set these eight observations to zero (the ± pairs' compounds are ≈ 0, so zeroing approximates the true two-day move) and report the full audit trail in the replication package. WTI is exempt from the filter: its April-2020 ±57% moves are real (the negative-futures episode). Section 4.1 shows that these eight prints generated a spurious rolling-TCI peak of 77.9% and a net-spillover reading of +428.6% for SUSA under the original first-order specification (76.5% under the lag-2 specification adopted here, versus 35–36% on cleaned data) — a material distortion that motivates reporting cleaning transparently.

### 3.2. Diebold–Yilmaz connectedness

We estimate a VAR(p) on the return vector x(t) of all N = 13 assets,

x(t) = Σₖ Φₖ x(t−k) + ε(t),  ε(t) ~ (0, Σ),

with lag order p = 2 selected by BIC (BIC = 78,954 vs. 79,789 for p = 1). From the generalized forecast-error variance decomposition (GFEVD) of Koop et al. [23] and Pesaran and Shin [24] at horizon H = 10, we obtain the order-invariant share θ̃ᵢⱼ of asset i's forecast-error variance explained by asset j's shocks, row-normalized to sum to 100%. The total connectedness index (TCI) is the mean off-diagonal share; directional "to" and "from" spillovers are column and row off-diagonal sums; net spillover Sᵢ = TOᵢ − FROMᵢ identifies transmitters (Sᵢ > 0) and receivers (Sᵢ < 0). Dynamics are captured by re-estimating the system over a rolling window of W = 200 trading days (1,797 windows).

### 3.3. TVP-VAR with forgetting factors — and a stability caveat

Following Antonakakis et al. [9], coefficients evolve as random walks estimated by a Kalman filter with forgetting factor λ = 0.99 (observations lose half weight after ≈ 69 days), and the covariance follows an exponentially weighted moving average with κ = 0.99. A parameter-count caveat motivates our reporting choice: with N = 13 and p = 2 the filter adapts 351 coefficients per step against an effective memory of ~100 observations, which is under-determined. We confirm empirically that the 13-asset forgetting-factor filter produces inflated late-sample TCI (mean 69.8%) and explosive net spillovers (|net| up to 886%) for near-zero-variance assets, and we therefore (i) report it only as a documented stability exercise with a λ/κ-sensitivity table, and (ii) base dynamic inference on the six-primary-asset TVP-VAR (78 coefficients), which is stable (max |net| = 143%) and highly correlated (0.71) with the 13-asset rolling TCI.

### 3.4. Quantile VAR tail connectedness

To capture tail regimes we estimate the QVAR of Ando et al. [10] at τ ∈ {0.05, 0.25, 0.50, 0.75, 0.95} — equation-by-equation quantile regressions with p = 2, followed by GFEVD on the quantile coefficients with the quantile-residual covariance. τ = 0.05 (0.95) corresponds to the bear (bull) tail.

### 3.5. GARCH conditional volatilities

Conditional volatilities σ(i,t) from standard GARCH(1,1) models [30] (Gaussian innovations, maximum likelihood) serve two purposes: a volatility description of each segment, and features for the forecasting exercise. All estimated persistences α + β lie in [0.962, 0.9999] and remain strictly below unity for every asset, so all conditional-variance processes are stationary.

### 3.6. Forecasting feasibility design

Forecast targets are the rolling-DY series TCI, Net_THNQ, and Net_ICLN — system-wide connectedness, the AI-technology net spillover, and the clean-energy net spillover. Features are the 13 returns and 13 GARCH volatilities stacked into 10-day input windows, standardized with training-set statistics only. The chronological split is 60/20/20 (train: Apr 2019–Jun 2023, 1,068 usable sequences; validation: Jul 2023–Dec 2024, 359; test: Dec 2024–May 2026, 360). Benchmarks: persistence (ŷ(t+1) = y(t)), AR(1), and Ridge regression. Deep models (Figure 1): a two-layer LSTM [31] (hidden 64, dropout 0.2) with a linear head, and an LSTM-KAN hybrid replacing the head with a two-layer KAN decoder (64→6→3; B-spline edges, grid 3, order 3, L1 sparsity 0.01), trained jointly end-to-end with Adam (lr 10⁻³, weight decay 10⁻⁵), early stopping (patience 20), and five seeds per model; test predictions are the five-seed ensemble mean. Evaluation uses RMSE, MAE, out-of-sample R², and Diebold–Mariano [25] tests with Newey–West [26] variance against persistence.

**[Insert Hybrid fig here]**

**Figure 1.** Schematic of the two deep-forecasting architectures: (**a**) the two-layer LSTM benchmark (hidden 64, dropout 0.2) with a linear output head; (**b**) the LSTM-KAN hybrid, which replaces the head with a two-layer Kolmogorov–Arnold decoder (64→6→3) whose edges carry learnable B-spline activation functions.

## 4. Results

### 4.1. Descriptive statistics and the cost of bad data

Table 1 reports descriptive statistics of the cleaned daily log-returns. All series are fat-tailed (Jarque–Bera rejects normality at the 1% level) and stationary (ADF p < 0.001 for all; KPSS p > 0.10 for all except GLD, p = 0.023, which we flag and retain given the unambiguous ADF evidence and the bounded nature of daily returns). WTI is the most volatile series (std 3.24%), GRNB the least (0.30%).

**Table 1.** Descriptive statistics of daily log-returns, cleaned data (N = 1,997).

| Asset | Mean | Std | Min | Max | Skew | Kurt | JB | ADF p | KPSS p |
|---|---|---|---|---|---|---|---|---|---|
| THNQ | 0.070 | 1.774 | −10.60 | 12.03 | −0.155 | 4.19 | 1,469 | <0.001 | >0.10 |
| REMX | 0.029 | 2.534 | −17.42 | 13.70 | −0.092 | 3.29 | 905 | <0.001 | >0.10 |
| ROBT | 0.029 | 1.626 | −12.62 | 11.02 | −0.517 | 7.27 | 4,483 | <0.001 | >0.10 |
| SRVR | 0.015 | 1.365 | −10.60 | 9.88 | −0.257 | 7.90 | 5,211 | <0.001 | >0.10 |
| NLR | 0.050 | 1.658 | −12.43 | 9.48 | −0.323 | 6.60 | 3,661 | <0.001 | >0.10 |
| ICLN | 0.040 | 1.844 | −13.71 | 10.80 | −0.379 | 5.94 | 2,985 | <0.001 | >0.10 |
| GRNB | −0.004 | 0.300 | −1.66 | 1.69 | −0.232 | 2.41 | 502 | <0.001 | >0.10 |
| SUSA | 0.048 | 1.232 | −10.91 | 9.98 | −0.343 | 11.61 | 11,256 | <0.001 | >0.10 |
| CRBN | 0.038 | 1.146 | −11.67 | 8.46 | −0.840 | 14.33 | 17,331 | <0.001 | >0.10 |
| DSI | 0.049 | 1.272 | −12.85 | 9.56 | −0.520 | 13.32 | 14,861 | <0.001 | >0.10 |
| WTI | 0.000 | 3.241 | −56.86 | 58.12 | −0.466 | 106.08 | 936,345 | <0.001 | >0.10 |
| GLD | 0.064 | 1.023 | −10.84 | 6.17 | −0.808 | 9.68 | 8,016 | <0.001 | 0.023 |
| USD | 0.003 | 0.415 | −2.14 | 1.64 | −0.193 | 1.94 | 324 | <0.001 | >0.10 |

*Note.* Kurt is excess (Fisher) kurtosis, so 0 corresponds to a Gaussian distribution; returns are in percent.

The correlation matrix (Figure 2) reveals three blocks: an ESG block (DSI–SUSA r = 0.58; DSI–CRBN 0.54; SUSA–CRBN 0.47), an AI/technology block (THNQ–ROBT 0.51; THNQ–SRVR 0.46), and near-isolated macro assets (the largest pairwise correlation with either block is WTI–THNQ, r = 0.10). ICLN correlates only 0.07 with THNQ — raw correlations understate the directional shock transmission revealed next. GARCH(1,1) conditional volatilities (Figure 3) show the expected crisis concentration: mean annualized volatility ranges from 4.6% (GRNB) and 6.4% (USD) to 27.6% (ICLN) and 40.1% (WTI), and every risky asset peaks in March–May 2020, with WTI's conditional volatility reaching an annualized ~490% during the negative-futures episode.

**[Insert Figure 2 here]**

**Figure 2.** Pearson correlation matrix of the thirteen cleaned daily log-return series, 4 June 2018 – 12 May 2026 (N = 1,997).

**[Insert Figure 3 here]**

**Figure 3.** GARCH(1,1) conditional volatilities σ(i,t) of six primary assets (daily, percent, June 2018 – May 2026). Shaded bands: COVID-19 crash (orange), 2022 energy/geopolitical shock (purple), AI-rally window (green).


**Why cleaning matters.** Re-estimating the rolling system on the raw data produces a spurious TCI peak dated 20 February 2020 — exactly the SUSA/DSI bad-tick days, two weeks *before* the genuine COVID crash: 77.9% under the first-order specification of the original analysis and 76.5% under the lag-2 specification adopted here, versus 35–36% on the cleaned data. The original specification simultaneously produced a one-day net spillover of +428.6% for SUSA, a normalization blow-up. After cleaning, the maximum daily net spillover is 203.7% and the February-2020 artifact disappears. Connectedness estimates built on unaudited data can thus be materially wrong, and we recommend the audit trail as standard practice.

### 4.2. Static connectedness of the sustainability-finance network

The full-sample static DY system (p = 2, H = 10) yields TCI = **35.0%**: about one-third of forecast-error variance is cross-market (Figure 4a). The net-spillover hierarchy (Table 2, Figure 4b) is unambiguous:

**Table 2.** Static directional connectedness, 13 assets (cleaned data).

| Asset | TO % | FROM % | NET % | Own share % | Role |
|---|---|---|---|---|---|
| SRVR | 81.6 | 36.2 | **+45.5** | 63.8 | transmitter |
| ROBT | 89.2 | 44.2 | **+45.0** | 55.8 | transmitter |
| THNQ | 72.8 | 43.8 | **+29.0** | 56.2 | transmitter |
| REMX | 60.9 | 34.6 | **+26.3** | 65.4 | transmitter |
| USD | 2.0 | 1.6 | +0.4 | 98.4 | isolated |
| WTI | 2.3 | 3.4 | −1.1 | 96.6 | isolated |
| GLD | 1.1 | 2.7 | −1.6 | 97.3 | isolated |
| SUSA | 51.1 | 55.9 | −4.7 | 44.2 | receiver |
| DSI | 50.4 | 58.3 | −8.0 | 41.7 | receiver |
| CRBN | 30.4 | 41.4 | −11.0 | 58.6 | receiver |
| GRNB | 2.2 | 18.6 | −16.4 | 81.4 | receiver |
| NLR | 6.5 | 51.9 | −45.4 | 48.1 | receiver |
| ICLN | 5.1 | 63.0 | **−57.9** | 37.0 | dominant receiver |

Three findings stand out. First, the **AI/technology complex is the shock source**: SRVR (+45.5%), ROBT (+45.0%), and THNQ (+29.0%), joined by critical materials REMX (+26.3%), transmit far more than they receive. Second, **clean energy is the shock absorber**: ICLN receives 63.0% of its variance from the system while contributing only 5.1% (net −57.9%); nuclear (NLR, −45.4%) and green bonds (GRNB, −16.4%) follow. The largest pairwise channel into the clean-energy complex runs from ROBT to ICLN (28.9% of ICLN's forecast-error variance), followed by SRVR→ICLN (11.1%) and THNQ→ICLN (10.6%); together the AI/technology-and-materials complex accounts for roughly 95% of ICLN's externally explained variance. (The largest single off-diagonal link overall, SUSA→DSI at 28.9%, sits inside the ESG block.) Third, macro assets are **structurally isolated** (|net| ≤ 1.6%; own shares 96.6–98.4%) — oil, gold, and the dollar neither drive nor absorb the sustainability network's variance on average over the full sample.

**[Insert Figure 4 here]**

**Figure 4.** Full-sample static Diebold–Yilmaz connectedness of the thirteen-asset system (VAR(2), generalized FEVD, H = 10, percent). (**a**) Row-normalized GFEVD matrix; (**b**) net directional spillovers (TO − FROM): blue = net transmitters, red = net receivers.


### 4.3. Dynamic connectedness

The rolling TCI (Figure 5) averages **48.8%** (range 35.0–58.2%). It spikes to 52.4% in March–April 2020 (COVID-19), troughs near 42% in late 2021, climbs through the 2022 energy/geopolitical shock, and reaches its global maximum of **58.2% in February 2023**, then decays through the AI-rally window into a 43–53% band in 2024–2026. Rolling net spillovers (Figure 6) confirm persistent roles: on average SRVR (+61.4%), THNQ (+45.9%), REMX (+45.0%), and ROBT (+27.0%) transmit; ICLN (−61.8%), NLR (−42.5%), DSI (−29.3%), and GRNB (−18.5%) receive; macro assets oscillate around zero.

**[Insert Figure 5 here]**

**Figure 5.** Rolling-window total connectedness index (200-day windows re-estimated daily, VAR(2), generalized FEVD, H = 10; 1,797 windows). Dashed line: full-period mean (48.8%); shaded bands as in Figure 3.

**[Insert Figure 6 here]**

**Figure 6.** Rolling-window net directional spillovers (percent), same specification as Figure 5. (**a**) Net transmitters; (**b**) net receivers (solid lines) and macro assets (dotted lines).


The six-primary-asset TVP-VAR (Figure 7) corroborates the dynamics: its TCI tracks the 13-asset rolling series (correlation 0.71), jumping from ~10% to ~38% at COVID and exceeding 50% during the 2022 shock; THNQ is its dominant average transmitter (+49.5%), with WTI (+27.8%) — the oil shock channel — and USD (−64.4%) and ICLN (−19.4%) as receivers. As documented in Section 3.3, the 13-asset forgetting-factor specification is under-determined; its sensitivity table (replication package, `tvpvar_lambda_sensitivity.csv`) shows mean TCI ranging from 31.4% (λ = κ = 1, recursive OLS) to 87.1% (λ = κ = 0.96), underscoring that TVP-VAR levels — though not the timing of its peaks — are calibration-sensitive in large systems.

**[Insert Figure 7 here]**

**Figure 7.** Six-primary-asset TVP-VAR with forgetting factors (λ = κ = 0.99; THNQ, ROBT, ICLN, WTI, GLD, USD; p = 2, H = 10). (**a**) TVP-VAR total connectedness (solid) versus the thirteen-asset rolling-window TCI (dashed); (**b**) TVP-VAR net directional spillovers. Shaded bands as in Figure 3.


### 4.4. Tail connectedness: an asymmetric U

QVAR connectedness across market states (Table 3, Figure 8) shows a **U-shaped but asymmetric** pattern: TCI = 42.1% in the bear tail, 35.0% at τ = 0.25, 33.2% at the median, 33.5% at τ = 0.75, and 36.8% in the bull tail. Connectedness intensifies in both extreme regimes — diversification within the sustainability-finance network fails when most needed — but the intensification is roughly twice as strong in crashes (+8.9 pp vs. median) as in euphoric rallies (+3.6 pp). Role structure is state-invariant: ICLN is the dominant receiver at every quantile (−55.8% to −60.4%), and ROBT is the strongest tail transmitter (≈ +53.5% at both τ = 0.05 and τ = 0.95).

**Table 3.** QVAR tail connectedness (selected assets).

| Quantile | TCI % | THNQ | ROBT | SRVR | ICLN | NLR | GRNB |
|---|---|---|---|---|---|---|---|
| 0.05 (bear) | **42.1** | +25.8 | +53.5 | +43.7 | −60.4 | −46.6 | −34.3 |
| 0.25 | 35.0 | +30.1 | +44.7 | +40.2 | −56.1 | −41.2 | −22.9 |
| 0.50 | 33.2 | +28.5 | +37.6 | +36.3 | −55.8 | −38.7 | −11.5 |
| 0.75 | 33.5 | +29.7 | +41.5 | +36.8 | −57.5 | −39.7 | −11.8 |
| 0.95 (bull) | **36.8** | +25.9 | +53.8 | +39.2 | −59.5 | −46.5 | −17.9 |

**[Insert Figure 8 here]**

**Figure 8.** Quantile-VAR connectedness across market states (τ ∈ {0.05, 0.25, 0.50, 0.75, 0.95}; p = 2; generalized FEVD, H = 10). (**a**) Total connectedness index by quantile; (**b**) net spillovers by asset (columns) and quantile (rows), percent — red = transmit, blue = receive.


### 4.5. Forecasting feasibility: persistence dominates

Table 4 and Figure 9 report the one-step-ahead forecasting assessment on the untouched test period (Dec 2024–May 2026).

**Table 4.** Out-of-sample forecast performance (test set, 360 obs).

| Model | TCI RMSE | R² | Net_THNQ RMSE | R² | Net_ICLN RMSE | R² |
|---|---|---|---|---|---|---|
| Persistence | **0.311** | **0.985** | **1.204** | **0.988** | **1.008** | **0.981** |
| AR(1) | 0.312 | 0.985 | 1.208 | 0.988 | 1.017 | 0.981 |
| Ridge | 7.077 | −6.513 | 54.930 | −24.718 | 20.108 | −6.580 |
| LSTM | 2.745 | −0.130 | 19.143 | −2.123 | 11.206 | −1.354 |
| LSTM-KAN | 5.251 | −3.137 | 20.740 | −2.666 | 8.264 | −0.280 |

**[Insert Figure 9 here]**

**Figure 9.** One-step-ahead out-of-sample forecasts on the untouched test period (December 2024 – May 2026; 360 observations): actual (solid black), persistence (dashed), five-seed LSTM (red), five-seed LSTM-KAN (green); legends report out-of-sample R². Panels: TCI (top), Net_THNQ (middle), Net_ICLN (bottom).


Persistence — forecasting tomorrow's connectedness as today's — attains out-of-sample R² of 0.98–0.99, because a 200-day rolling statistic replaces only 1/200 of its sample each day and is therefore near-unit-root by construction. AR(1) matches it; all three parametric and deep models are dramatically worse. Diebold–Mariano tests reject equal accuracy against persistence at the 1% level for both deep models on all three targets (DM statistics +5.4 to +11.7). Contrary to recent claims for related architectures, the LSTM-KAN hybrid does not improve on the plain LSTM here; it improves only on Net_ICLN (R² −0.28 vs. −1.35) while degrading TCI. A sensitivity check on first differences (Δ-targets) confirms the absence of exploitable signal: the LSTM attains R² ≈ ±0.01 against the zero-change baseline, and the hybrid is worse.

We draw two conclusions. First, daily one-step-ahead forecasting of rolling connectedness from return/volatility features is not informative beyond persistence; claimed deep-learning gains on such targets are uninterpretable without a persistence benchmark. Second, the practical early-warning content of our framework lies in the *level and tail behavior of connectedness itself* (Sections 4.2–4.4), not in point forecasts of its daily increments.

## 5. Discussion

### 5.1. Economic interpretation

The transmitter hierarchy — data infrastructure (SRVR), robotics (ROBT), AI equity (THNQ), and critical materials (REMX) at the source; clean-energy equities (ICLN), nuclear (NLR), and green bonds (GRNB) at the receiving end — is economically coherent with the AI–energy nexus [5]. AI-sector valuation cycles drive both the demand expectations for clean power and the risk appetite for the thematic-ETF complex; clean-energy assets, whose cash flows depend on policy-sensitive, capital-intensive projects, absorb those shocks rather than generate them — green-bond prices in particular are known to respond to economic-policy uncertainty [28]. The asymmetry of the U-shaped tail pattern (bear-tail TCI 42.1% vs. bull-tail 36.8%) aligns with flight-to-quality and correlated liquidation in crashes being stronger than euphoria-driven co-movement in booms [27], and extends Raggad and Bouri's [11] pairwise extreme-event evidence to a 13-asset system.

### 5.2. Implications

For **portfolio managers**, within-theme diversification across AI/clean-energy/ESG ETFs provides less protection than labels suggest: the network's TCI averages ~49% over time and rises above 55% in stress, and the ESG block is itself highly correlated (r ≈ 0.5–0.6). Genuine diversification requires assets outside the network — the macro assets' near-zero net spillovers confirm their hedging potential on average, though WTI becomes a transmitter during supply shocks (TVP-VAR); the dollar index's near-total isolation (own share 98.4%) is consistent with its distinct global funding- and safe-haven-currency role [29]. For **regulators and sustainability supervisors**, the persistent receiver status of ICLN/NLR/GRNB identifies clean-energy finance as the network's shock absorber: monitoring AI-sector volatility (e.g., ROBT/SRVR conditional volatility) is a direct transition-financing risk monitor. For **methodology**, our forecasting assessment implies that connectedness early-warning systems should monitor levels and quantile regimes rather than forecast daily increments, and that spillover-forecasting studies should report persistence benchmarks and Diebold–Mariano tests as standard.

### 5.3. Limitations

Four limitations qualify our findings. First, eight observations were neutralized as data errors; although the ± reversal pattern supports the treatment, vendor-verified corrections would be preferable. Second, the forgetting-factor TVP-VAR is unstable at N = 13; we mitigated by reporting the six-asset specification and a sensitivity table, but fully Bayesian TVP-VAR with stochastic volatility is a natural extension. Third, rolling-window connectedness targets are mechanically persistent, so our forecasting assessment speaks to daily horizons; lower-frequency (weekly/monthly) or quantile-specific predictability may still exist. Fourth, the ETF proxies aggregate heterogeneous holdings; firm-level or holdings-based decompositions could sharpen the channels.

## 6. Conclusions

This study provides a cleaned, reproducible map of financial connectedness across the thirteen-asset sustainability-finance network from June 2018 to May 2026. The AI/technology complex and critical materials are the dominant net shock transmitters (SRVR +45.5%, ROBT +45.0%, THNQ +29.0%, REMX +26.3%); clean-energy assets are the dominant net receivers (ICLN −57.9%, NLR −45.4%, GRNB −16.4%); macro assets are structurally isolated on average. Total connectedness averages 48.8% over rolling windows, spikes in crises, and is U-shaped across market states with a pronounced bear-tail intensification (42.1% vs. 33.2% at the median). A rigorous out-of-sample assessment shows rolling connectedness is essentially unpredictable at the daily horizon beyond persistence — a cautionary benchmark result for the spillover-forecasting literature. For sustainability, the central message is that AI-market instability is a first-order, quantifiable transition-financing risk, and that monitoring the transmitter complex offers a practical early-warning channel for the resilience of energy-transition finance.

---

**Data Availability Statement.** All data-processing code, estimation scripts, result tables, and figures are provided in the accompanying replication package (`revised_paper_package.zip`), which reproduces every number in the manuscript from the raw returns file.

**Author Contributions.** [To be completed by authors per journal requirements.]

**Funding.** [To be completed.]

**Conflicts of Interest.** The authors declare no conflicts of interest.

## References

1. Hu, M.; Sima, Z.; Chen, S.; Huang, M. Does green finance promote low-carbon economic transition? *J. Clean. Prod.* 2023, 427, 139231.
2. Daugaard, D.; Ding, A. Global drivers for ESG performance: The body of knowledge. *Sustainability* 2022, 14, 2322.
3. Antar, M. The rise of AI in exchange-traded funds: Assessing robo-advisors and AI-exposed ETFs. *Comput. Econ.* 2026, 1–24.
4. D'Ecclesia, R.L.; Morelli, G.; Stefanelli, K. Energy ETF performance: The role of fossil fuels. *Energy Econ.* 2024, 131, 107332.
5. International Energy Agency. *Energy and AI*; IEA: Paris, France, 2025.
6. Smaga, P. *The Concept of Systemic Risk*; SRC Special Paper No. 5; Systemic Risk Centre, London School of Economics: London, UK, 2014.
7. Diebold, F.X.; Yilmaz, K. Better to give than to receive: Predictive directional measurement of volatility spillovers. *Int. J. Forecast.* 2012, 28, 57–66.
8. Diebold, F.X.; Yilmaz, K. On the network topology of variance decompositions: Measuring the connectedness of financial firms. *J. Econom.* 2014, 182, 119–134.
9. Antonakakis, N.; Chatziantoniou, I.; Gabauer, D. Refined measures of dynamic connectedness based on time-varying parameter vector autoregressions. *J. Risk Financ. Manag.* 2020, 13, 84.
10. Ando, T.; Greenwood-Nimmo, M.; Shin, Y. Quantile connectedness: Modeling tail behavior in the topology of financial networks. *Manag. Sci.* 2022, 68, 2401–2431.
11. Raggad, B.; Bouri, E. Artificial intelligence and clean/dirty energy markets: Tail-based pairwise connectedness and portfolio implications. *Future Bus. J.* 2025, 11, 29.
12. Khan, N.; Tariq, A.; Shah, S.Z.A.; Javed, H. Quantile time–frequency connectedness and spillover between artificial intelligence, clean energy, and traditional asset classes. *Future Bus. J.* 2026, 12, 106.
13. Tang, P.; Xu, W.; Wang, H. Network-based prediction of financial cross-sector risk spillover in China: A deep learning approach. *N. Am. J. Econ. Finance* 2024, 72, 102151.
14. Del Nero, L.; Giudici, P. Machine learning models to predict stock market spillovers. *Financ. Res. Lett.* 2025, 108508.
15. Ferrer, R.; Shahzad, S.J.H.; López, R.; Jareño, F. Time and frequency dynamics of connectedness between renewable energy stocks and crude oil prices. *Energy Econ.* 2018, 76, 1–20.
16. Reboredo, J.C. Green bond and financial markets: Co-movement, diversification and price spillover effects. *Energy Econ.* 2018, 74, 38–50.
17. Le, T.L.; Abakah, E.J.A.; Tiwari, A.K. Time and frequency domain connectedness and spillover among fintech, green bonds and cryptocurrencies in the age of the Fourth Industrial Revolution. *Technol. Forecast. Soc. Change* 2021, 162, 120382.
18. Babalos, V.; Sibande, X.; Bouri, E.; Gupta, R. Do investors in clean energy ETFs herd? The role of climate risks. *Rev. Behav. Finance* 2026, 18, 19–32.
19. Wei, J.; Yang, S.; Cui, Z. Unified GARCH-recurrent neural network in financial volatility forecasting. *arXiv* 2025, arXiv:2504.09380.
20. Liu, Z.; Wang, Y.; Vaidya, S.; Ruehle, F.; Halverson, J.; Soljačić, M.; Hou, T.Y.; Tegmark, M. KAN: Kolmogorov–Arnold Networks. In *Proceedings of the ICLR*, Singapore, 2025; pp. 70367–70413.
21. Cho, S.Y.; Lee, S.; Kim, H.G. Forecasting VIX using interpretable Kolmogorov–Arnold networks. *Expert Syst. Appl.* 2025, 294, 128781.
22. Inzirillo, G.; Genet, R. Kolmogorov–Arnold networks for time series: A survey. *SSRN Electron. J.* 2025.
23. Koop, G.; Pesaran, M.H.; Potter, S.M. Impulse response analysis in nonlinear multivariate models. *J. Econom.* 1996, 74, 119–147.
24. Pesaran, H.H.; Shin, Y. Generalized impulse response analysis in linear multivariate models. *Econ. Lett.* 1998, 58, 17–29.
25. Diebold, F.X.; Mariano, R.S. Comparing predictive accuracy. *J. Bus. Econ. Stat.* 1995, 13, 253–263.
26. Newey, W.K.; West, K.D. A simple, positive semi-definite, heteroskedasticity and autocorrelation consistent covariance matrix. *Econometrica* 1987, 55, 703–708.
27. Bouri, E.; Iqbal, N.; Klein, T. Climate policy uncertainty and the price dynamics of green and brown energy stocks. *Financ. Res. Lett.* 2022, 47, 102740.
28. Pham, L.; Nguyen, C.P. How do stock, oil, and economic policy uncertainty influence the green bond market? *Financ. Res. Lett.* 2022, 45, 102128.
29. Avdjiev, S.; Du, W.; Koch, C.; Shin, H.S. The dollar, bank leverage, and deviations from covered interest parity. *Am. Econ. Rev. Insights* 2019, 1, 193–208.
30. Bollerslev, T. Generalized autoregressive conditional heteroskedasticity. *J. Econom.* 1986, 31, 307–327.
31. Hochreiter, S.; Schmidhuber, J. Long short-term memory. *Neural Comput.* 1997, 9, 1735–1780.
32. Tabash, M.I.; Issa, S.S.; Alnahhal, M.; Mamadiyarov, Z.; Drachal, K. Time-varying global financial stress contagion in a decade of trade wars and geopolitical fractures. *Risks* 2026, 14, 70.
