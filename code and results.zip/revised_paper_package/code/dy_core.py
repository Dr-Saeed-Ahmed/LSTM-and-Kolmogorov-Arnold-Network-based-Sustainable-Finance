"""
dy_core.py — Core Diebold–Yilmaz connectedness functions (shared by all scripts).
Generalized FEVD (Koop et al. 1996; Pesaran & Shin 1998) from a VAR(p).
"""
import numpy as np


def estimate_var(X, p=2):
    """OLS VAR(p) with intercept. X: (T, N) array.
    Returns (Phi, Sigma): list of p NxN coefficient matrices; NxN residual covariance (MLE)."""
    T, N = X.shape
    Y = X[p:]
    Xreg = np.column_stack([np.ones(T - p)] + [X[p - k:T - k] for k in range(1, p + 1)])
    B, *_ = np.linalg.lstsq(Xreg, Y, rcond=None)          # (1+pN) x N
    E = Y - Xreg @ B
    Sigma = (E.T @ E) / (T - p)                           # MLE covariance
    Phi = [B[1 + k * N:1 + (k + 1) * N].T for k in range(p)]  # each NxN, Phi[k][i,j]: effect of j (lag k+1) on i
    return Phi, Sigma


def gfevd(Phi, Sigma, H=10):
    """Generalized forecast-error variance decomposition, row-normalized, in percent.
    theta[i, j] = % of asset i's H-step FEV attributable to asset j's shock."""
    N = Sigma.shape[0]
    p = len(Phi)
    # MA coefficients by recursion: A_0 = I, A_h = sum_k Phi_k A_{h-k}
    A = [np.eye(N)]
    for h in range(1, H):
        Ah = np.zeros((N, N))
        for k in range(min(h, p)):
            Ah += Phi[k] @ A[h - 1 - k]
        A.append(Ah)
    sig = np.diag(Sigma)
    num = np.zeros((N, N))
    den = np.zeros(N)
    for h in range(H):
        AS = A[h] @ Sigma
        num += AS ** 2
        den += np.diag(AS @ A[h].T)
    theta = num / sig[None, :] / den[:, None]
    return theta / theta.sum(axis=1, keepdims=True) * 100


def connectedness(theta):
    """From row-normalized GFEVD (%): TCI, TO, FROM, NET."""
    N = theta.shape[0]
    to = theta.sum(axis=0) - np.diag(theta)    # column off-diagonal sums (transmit to others)
    frm = theta.sum(axis=1) - np.diag(theta)   # row off-diagonal sums (receive from others)
    net = to - frm
    tci = frm.sum() / N
    return tci, to, frm, net


def var_bic(X, p):
    """BIC for VAR(p) — used for lag-order selection."""
    T, N = X.shape
    Phi, Sig = estimate_var(X, p=p)
    T_eff = T - p
    ll = -0.5 * T_eff * (N * np.log(2 * np.pi) + np.log(np.linalg.det(Sig)) + N)
    k = N * (1 + p * N)
    return -2 * ll + k * np.log(T_eff)
