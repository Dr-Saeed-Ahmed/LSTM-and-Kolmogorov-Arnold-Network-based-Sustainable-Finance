"""
05_ml_forecasting.py — Forecasting feasibility assessment (Section 4.5 of the paper).

Targets: rolling-DY TCI, Net_THNQ, Net_ICLN (13-asset system, cleaned data).
Features: 13 log-returns + 13 GARCH(1,1) volatilities, 10-day input window,
          standardized with TRAIN-set statistics only (no leakage).
Split: chronological 60/20/20.

Models: Persistence (y_hat(t+1)=y(t)), AR(1), Ridge, plain LSTM (2x64, linear head),
        LSTM-KAN hybrid (KAN decoder 64->6->3, B-spline edges G=3 K=3, L1=0.01).
Deep models: 5 seeds, Adam lr=1e-3, weight decay 1e-5, batch 64, early stopping (20),
             ReduceLROnPlateau(8, 0.5), max 150 epochs; test predictions are the
             5-seed ensemble mean.
Evaluation: RMSE, MAE, out-of-sample R^2, Diebold–Mariano vs persistence (NW lag 1).

HONEST RESULT (why the ML section was cut to a feasibility assessment):
persistence attains R^2 ≈ 0.98-0.99 because 200-day rolling statistics are near-unit-root;
LSTM and LSTM-KAN attain negative out-of-sample R^2 and are significantly WORSE than
persistence (DM p < 0.01). LSTM-KAN does not beat plain LSTM on cleaned data.
"""
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from scipy import stats as sstats
from sklearn.linear_model import Ridge

LAG, HID, OUT_F = 10, 64, 3
SEEDS = [42, 7, 123, 2024, 555]
TGT = ["TCI", "Net_THNQ", "Net_ICLN"]


# ---------------- KAN layer ----------------
class KANLayer(nn.Module):
    def __init__(self, in_f, out_f, G=3, K=3, grid=(-4.0, 4.0)):
        super().__init__()
        self.in_f, self.out_f, self.G, self.K = in_f, out_f, G, K
        a, b = grid
        interior = torch.linspace(a, b, G + 1)
        pad = torch.arange(1, K + 1, dtype=torch.float32)
        knots = torch.cat([interior[0] - (b - a) / G * pad.flip(0), interior,
                           interior[-1] + (b - a) / G * pad])
        self.register_buffer("knots", knots)
        self.nb = G + K
        self.coef = nn.Parameter(torch.empty(out_f, in_f, self.nb))
        nn.init.uniform_(self.coef, -0.1, 0.1)
        self.w_b = nn.Parameter(torch.ones(out_f, in_f))
        self.w_s = nn.Parameter(torch.ones(out_f, in_f))

    def basis(self, x):
        x = x.unsqueeze(-1)
        k = self.knots
        B = ((x >= k[:-1]) & (x < k[1:])).float()
        for d in range(1, self.K + 1):
            Bl, Br = B[..., :-1], B[..., 1:]
            d1 = k[d:-1] - k[:-d - 1]; d2 = k[d + 1:] - k[1:-d]
            xu = x[..., 0].unsqueeze(-1)
            w1 = torch.where(d1 > 0, (xu - k[:-d - 1]) / d1.clamp(min=1e-8), torch.zeros_like(d1))
            w2 = torch.where(d2 > 0, (k[d + 1:] - xu) / d2.clamp(min=1e-8), torch.zeros_like(d2))
            B = w1 * Bl + w2 * Br
        return B

    def forward(self, x):
        B = self.basis(x)
        sil = nn.functional.silu(x)
        return (torch.einsum("...i,oi->...o", sil, self.w_b)
                + torch.einsum("...ic,oic->...o", B, self.coef * self.w_s.unsqueeze(-1)))


class LSTMLinear(nn.Module):
    def __init__(self, in_f, hid=HID, out_f=OUT_F):
        super().__init__()
        self.lstm = nn.LSTM(in_f, hid, num_layers=2, batch_first=True, dropout=0.2)
        self.head = nn.Linear(hid, out_f)
    def forward(self, x):
        h, _ = self.lstm(x)
        return self.head(h[:, -1, :])


class LSTMKAN(nn.Module):
    def __init__(self, in_f, hid=HID, out_f=OUT_F, mid=6):
        super().__init__()
        self.lstm = nn.LSTM(in_f, hid, num_layers=2, batch_first=True, dropout=0.2)
        self.kan1 = KANLayer(hid, mid)
        self.kan2 = KANLayer(mid, out_f)
    def forward(self, x):
        h, _ = self.lstm(x)
        return self.kan2(self.kan1(h[:, -1, :]))


def train_model(model, Xtr, Ytr, Xva, Yva, seed, l1=0.0, max_epochs=150, patience=20):
    torch.manual_seed(seed); np.random.seed(seed)
    opt = torch.optim.Adam(model.parameters(), lr=1e-3, weight_decay=1e-5)
    sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, patience=8, factor=0.5)
    best_va, best_state, bad = np.inf, None, 0
    for ep in range(max_epochs):
        model.train()
        perm = torch.randperm(len(Xtr))
        for i in range(0, len(Xtr), 64):
            xb, yb = Xtr[perm[i:i + 64]], Ytr[perm[i:i + 64]]
            loss = nn.functional.mse_loss(model(xb), yb)
            if l1 > 0 and hasattr(model, "kan1"):
                loss = loss + l1 * sum(m.coef.abs().sum() for m in [model.kan1, model.kan2])
            opt.zero_grad(); loss.backward(); opt.step()
        model.eval()
        with torch.no_grad():
            va = nn.functional.mse_loss(model(Xva), Yva).item()
        sched.step(va)
        if va < best_va - 1e-6:
            best_va, best_state, bad = va, {k: v.clone() for k, v in model.state_dict().items()}, 0
        else:
            bad += 1
        if bad >= patience:
            break
    model.load_state_dict(best_state)
    return model


def metrics(y, yh):
    e = yh - y
    return np.sqrt((e ** 2).mean()), np.abs(e).mean(), 1 - (e ** 2).sum() / ((y - y.mean()) ** 2).sum()


def dm_test(e1, e2, h=1):
    d = e1 ** 2 - e2 ** 2
    T = len(d)
    lr = np.var(d, ddof=1) + sum(2 * (1 - k / (h + 1)) * np.cov(d[k:], d[:-k])[0, 1]
                                 for k in range(1, h + 1))
    stat = d.mean() / np.sqrt(lr / T)
    return stat, 2 * (1 - sstats.norm.cdf(abs(stat)))


def main():
    r = pd.read_csv("../results/returns_cleaned.csv", parse_dates=["Date"]).set_index("Date")
    vols = pd.read_csv("../results/garch11_conditional_volatilities.csv",
                       parse_dates=["Date"]).set_index("Date")
    roll = pd.read_csv("../results/corrected_rollingDY_results_13ETF.csv",
                       parse_dates=["Date"])
    assets = r.columns.tolist()
    feats = assets + [f"GARCH_{a}" for a in assets]

    data = roll[["Date"] + TGT].merge(r.join(vols).reset_index(), on="Date").set_index("Date")
    data.to_csv("../results/ml_dataset.csv")
    n = len(data); i_tr, i_va = int(0.6 * n), int(0.8 * n)

    X_all = data[feats].values.astype(np.float32)
    Y_all = data[TGT].values.astype(np.float32)
    Xs = (X_all - X_all[:i_tr].mean(0)) / X_all[:i_tr].std(0)

    xs, ys, idx = [], [], []
    for t in range(LAG - 1, len(Xs) - 1):
        xs.append(Xs[t - LAG + 1:t + 1]); ys.append(Y_all[t + 1]); idx.append(t + 1)
    Xsq = np.array(xs, dtype=np.float32); Ysq = np.array(ys, dtype=np.float32); Iidx = np.array(idx)
    tr_m = Iidx < i_tr; va_m = (Iidx >= i_tr) & (Iidx < i_va); te_m = Iidx >= i_va
    Yte = Ysq[te_m]
    Yprev = Y_all[Iidx[te_m] - 1]

    preds = {}
    preds["Persistence"] = Yprev
    ar = np.zeros_like(Yte)
    for j in range(3):
        b, a = np.polyfit(Y_all[Iidx[tr_m] - 1, j], Ysq[tr_m][:, j], 1)
        ar[:, j] = a + b * Yprev[:, j]
    preds["AR(1)"] = ar
    preds["Ridge"] = Ridge(alpha=1.0).fit(Xsq[tr_m][:, -1, :], Ysq[tr_m]).predict(Xsq[te_m][:, -1, :])

    for name, ctor, l1 in [("LSTM", LSTMLinear, 0.0), ("LSTM-KAN", LSTMKAN, 0.01)]:
        pr = []
        for s in SEEDS:
            m = train_model(ctor(26), torch.tensor(Xsq[tr_m]), torch.tensor(Ysq[tr_m]),
                            torch.tensor(Xsq[va_m]), torch.tensor(Ysq[va_m]), seed=s, l1=l1)
            m.eval()
            with torch.no_grad():
                pr.append(m(torch.tensor(Xsq[te_m])).numpy())
        preds[name] = np.array(pr).mean(0)
        print(f"{name} done (5-seed ensemble)")

    rows = []
    for mname, pr in preds.items():
        for j, t_ in enumerate(TGT):
            rm, ma, r2 = metrics(Yte[:, j], pr[:, j])
            if mname == "Persistence":
                dm_s, dm_p = np.nan, np.nan   # reference model: DM against itself undefined
            else:
                dm_s, dm_p = dm_test(pr[:, j] - Yte[:, j], Yprev[:, j] - Yte[:, j])
            rows.append({"Model": mname, "Target": t_, "RMSE": round(rm, 3), "MAE": round(ma, 3),
                         "R2_oos": round(r2, 3), "DM_vs_persistence": round(dm_s, 2),
                         "DM_p": round(dm_p, 4)})
    tbl = pd.DataFrame(rows)
    tbl.to_csv("../results/table_forecast_performance.csv", index=False)
    print(tbl.pivot(index="Model", columns="Target", values="RMSE"))
    print(tbl.pivot(index="Model", columns="Target", values="R2_oos"))

    # --- Sensitivity: first-difference (Delta) targets vs zero-change baseline ---
    # Manuscript Section 4.5: is there exploitable signal in daily *changes* of
    # connectedness? Baseline predicts Delta y = 0 (zero change).
    # one-step-ahead change target: y(t+1) - y(t), features end at t (same rows as Ysq)
    dYsq = (Ysq - Y_all[Iidx - 1]).astype(np.float32)
    dYtr, dYva, dYte = dYsq[tr_m], dYsq[va_m], dYsq[te_m]
    sens = []
    for name, ctor, l1 in [("LSTM", LSTMLinear, 0.0), ("LSTM-KAN", LSTMKAN, 0.01)]:
        pr = []
        for s in SEEDS:
            m = train_model(ctor(26), torch.tensor(Xsq[tr_m]), torch.tensor(dYtr),
                            torch.tensor(Xsq[va_m]), torch.tensor(dYva), seed=s, l1=l1)
            m.eval()
            with torch.no_grad():
                pr.append(m(torch.tensor(Xsq[te_m])).numpy())
        phat = np.array(pr).mean(0)
        for j, t_ in enumerate(TGT):
            sse = ((phat[:, j] - dYte[:, j]) ** 2).sum()
            sst = (dYte[:, j] ** 2).sum()          # zero-change baseline: predict Delta = 0
            r2 = 1.0 - sse / sst
            sens.append({"Model": name, "Target": t_,
                         "R2_oos_vs_zero_change": round(float(r2), 4)})
        print(f"Delta-target sensitivity: {name} done")
    sens_df = pd.DataFrame(sens)
    sens_df.to_csv("../results/delta_target_sensitivity.csv", index=False)
    print(sens_df.pivot(index="Model", columns="Target", values="R2_oos_vs_zero_change"))


if __name__ == "__main__":
    main()
