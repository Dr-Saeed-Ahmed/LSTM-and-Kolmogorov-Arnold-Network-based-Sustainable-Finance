"""
01_data_cleaning.py — Load raw daily log-returns, detect and neutralize bad ticks,
save cleaned returns + audit trail.

Bad-tick rule: for equity/bond ETFs (all except WTI), |daily log-return| > 20% is
physically implausible under US market-wide circuit breakers (trading halts at -20%).
The 8 detected errors include impossible values beyond -100% (REMX -109.9%) and
paired +/- reversals (classic bad-print-and-correct patterns). They are set to 0
(zeroing a bad-tick pair approximates the true two-day move, e.g. -109.86 + 109.20
= -0.66%). WTI is exempt: its Apr-2020 +/-57% moves are real (negative-futures episode).

RECOMMENDATION: verify these 8 prints against the original price source and replace
with corrected returns if the vendor provides fixes.
"""
import numpy as np
import pandas as pd

RAW = "../data/Returns_Data.csv"
OUT_RET = "../results/returns_cleaned.csv"
OUT_AUDIT = "../results/cleaning_audit.csv"
OUT_STATS = "../results/table_descriptive_stats_cleaned.csv"

def main():
    r = pd.read_csv(RAW, parse_dates=["Date"]).set_index("Date").sort_index()

    # Canonical ticker fix: the raw file's column "NCLR" is the VanEck Uranium &
    # Nuclear Energy ETF, whose actual ticker is NLR. Rename so that text, code,
    # and figures all use the canonical ticker.
    if "NCLR" in r.columns:
        r = r.rename(columns={"NCLR": "NLR"})
        print("Renamed raw column NCLR -> NLR (canonical ticker)")

    assets = r.columns.tolist()
    etfs = [c for c in assets if c != "WTI"]

    bad = (r[etfs].abs() > 20)
    audit = []
    for c in etfs:
        for dt in bad.index[bad[c]]:
            audit.append({"asset": c, "date": dt.date(), "raw_return_%": round(r.loc[dt, c], 3),
                          "treatment": "set to 0 (bad tick)"})
    audit = pd.DataFrame(audit)
    audit.to_csv(OUT_AUDIT, index=False)

    r_clean = r.copy()
    r_clean[etfs] = r_clean[etfs].mask(bad, 0.0)
    r_clean.to_csv(OUT_RET)

    # Descriptive statistics of the cleaned returns (manuscript Table 1).
    from scipy import stats as st
    from statsmodels.tsa.stattools import adfuller, kpss
    rows = []
    for c in assets:
        x = r_clean[c].values
        rows.append({"Asset": c, "Mean": x.mean(), "Std": x.std(ddof=1),
                     "Min": x.min(), "Max": x.max(),
                     "Skew": st.skew(x), "Kurt": st.kurtosis(x),
                     "JB": st.jarque_bera(x)[0],
                     "ADF_p": adfuller(x, regression="c", autolag="AIC")[1],
                     "KPSS_p": kpss(x, regression="c", nlags="auto")[1]})
    stats_df = pd.DataFrame(rows).set_index("Asset")
    stats_df.to_csv(OUT_STATS)
    print(f"Descriptive statistics -> {OUT_STATS}")

    print(f"Sample {r.index[0].date()} -> {r.index[-1].date()}, N = {len(r)}, assets = {len(assets)}")
    print(f"Bad ticks neutralized: {len(audit)}")
    print(audit.to_string(index=False))

if __name__ == "__main__":
    main()
