"""
06_make_figures.py — Regenerate all publication figures from the results CSVs.
Run AFTER 01–05. Saves PNGs (300 dpi) to ../figures/.
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.patches import Patch

EVENTS = [("COVID-19 Crash", "2020-02-01", "2020-06-30", "#fdae61"),
          ("Energy/Geopolit. Shock", "2022-01-01", "2022-12-31", "#8073ac"),
          ("AI Rally", "2023-06-01", "2024-09-30", "#66c2a5")]
FIG = "../figures/"

def shade(ax):
    for name, s, e, c in EVENTS:
        ax.axvspan(pd.Timestamp(s), pd.Timestamp(e), color=c, alpha=0.18, lw=0)

def main():
    r = pd.read_csv("../results/returns_cleaned.csv", parse_dates=["Date"]).set_index("Date")
    assets = r.columns.tolist()
    roll = pd.read_csv("../results/corrected_rollingDY_results_13ETF.csv", parse_dates=["Date"])
    tvp6 = pd.read_csv("../results/tvpvar_results_6primary.csv", parse_dates=["Date"])
    qvar = pd.read_csv("../results/qvar_tail_connectedness_13ETF.csv")
    vols = pd.read_csv("../results/garch11_conditional_volatilities.csv",
                       parse_dates=["Date"]).set_index("Date")
    fc = pd.read_csv("../results/forecast_predictions_test.csv", parse_dates=["Date"])
    fevd = pd.read_csv("../results/corrected_static_FEVD_matrix_13ETF.csv", index_col=0)
    net = pd.read_csv("../results/corrected_static_net_spillovers_13ETF.csv", index_col=0)

    # Fig 1: correlation matrix
    C = r.corr()
    fig, ax = plt.subplots(figsize=(8.5, 7))
    Cm = C.mask(np.triu(np.ones_like(C, bool), k=1))
    im = ax.imshow(Cm, cmap="RdBu_r", vmin=-1, vmax=1)
    ax.set_xticks(range(13)); ax.set_yticks(range(13))
    ax.set_xticklabels(assets, rotation=45, ha="right", fontsize=8); ax.set_yticklabels(assets, fontsize=8)
    for i in range(13):
        for j in range(13):
            if i > j:
                v = Cm.values[i, j]
                ax.text(j, i, f"{v:.2f}", ha="center", va="center", fontsize=6.5,
                        color="white" if abs(v) > 0.6 else "black")
    fig.colorbar(im, shrink=0.8, label="Pearson r")
    ax.set_title("Pearson correlation of daily log-returns (Jun 2018–May 2026, N=1,997)", fontsize=10)
    plt.tight_layout(); plt.savefig(FIG + "Figure_2.png", dpi=300); plt.close()

    # Fig 2: static FEVD + net spillovers
    th = fevd.values
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13.5, 5.6), gridspec_kw={"width_ratios": [1.15, 1]})
    im = ax1.imshow(th, cmap="Blues", vmin=0, vmax=100)
    ax1.set_xticks(range(13)); ax1.set_yticks(range(13))
    ax1.set_xticklabels(fevd.columns, rotation=45, ha="right", fontsize=8)
    ax1.set_yticklabels(fevd.index, fontsize=8)
    for i in range(13):
        for j in range(13):
            if th[i, j] >= 0.5:
                ax1.text(j, i, f"{th[i,j]:.1f}", ha="center", va="center", fontsize=6.5,
                         color="white" if th[i, j] > 45 else "black")
    ax1.set_title("(a) GFEVD matrix (VAR p=2, H=10)", fontsize=10)
    fig.colorbar(im, ax=ax1, shrink=0.8, label="FEVD share (%)")
    nv = net["NET_%"]
    colors = ["#2166ac" if v > 0 else "#b2182b" for v in nv]
    ax2.barh(range(len(nv)), nv.values, color=colors, edgecolor="k", lw=0.4)
    ax2.set_yticks(range(len(nv))); ax2.set_yticklabels(nv.index, fontsize=8)
    for y, v in enumerate(nv.values):
        ax2.text(v + (1.2 if v > 0 else -1.2), y, f"{v:+.1f}%", va="center",
                 ha="left" if v > 0 else "right", fontsize=8)
    # pad axes so end-of-bar labels never overlap the tick labels
    xpos, xneg = max(nv.max(), 0.0), min(nv.min(), 0.0)
    ax2.set_xlim(xneg - 0.32 * abs(xneg), xpos + 0.30 * abs(xpos))
    ax2.axvline(0, color="k", lw=0.8); ax2.set_xlabel("Net spillover (%)")
    ax2.set_title("(b) Net directional spillovers", fontsize=10)
    plt.tight_layout(); plt.savefig(FIG + "Figure_4.png", dpi=300); plt.close()

    # Fig 3: rolling TCI
    fig, ax = plt.subplots(figsize=(12, 4.2))
    shade(ax)
    ax.plot(roll["Date"], roll["TCI"], color="#08306b", lw=1.2, label="Rolling TCI (200d)")
    ax.axhline(roll["TCI"].mean(), color="#b2182b", ls="--", lw=1,
               label=f"Full-period mean ({roll['TCI'].mean():.1f}%)")
    handles, _ = ax.get_legend_handles_labels()
    handles += [Patch(facecolor=c, alpha=0.3, label=n) for n, s, e, c in EVENTS]
    ax.legend(handles=handles, fontsize=8, loc="upper left", ncol=2)
    ax.set_ylabel("TCI (%)"); ax.set_title("Rolling-window TCI — 13 assets (cleaned)", fontsize=10)
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    plt.tight_layout(); plt.savefig(FIG + "Figure_5.png", dpi=300); plt.close()

    # Fig 4: rolling net spillovers
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 7), sharex=True)
    for ax in (ax1, ax2): shade(ax)
    for a, c in zip(["SRVR", "THNQ", "ROBT", "REMX"], ["#08519c", "#3182bd", "#6baed6", "#9ecae1"]):
        ax1.plot(roll["Date"], roll[f"Net_{a}"], lw=1.0, color=c, label=a)
    ax1.axhline(0, color="k", lw=0.7); ax1.legend(fontsize=8, ncol=4, loc="lower left")
    ax1.set_ylabel("Net spillover (%)"); ax1.set_title("(a) Net transmitters", fontsize=10)
    for a, c in zip(["ICLN", "NLR", "GRNB", "DSI", "CRBN", "SUSA"],
                    ["#cb181d", "#ef6548", "#fc8d59", "#fdae6b", "#fdd49e", "#a50f15"]):
        ax2.plot(roll["Date"], roll[f"Net_{a}"], lw=1.0, color=c, label=a)
    for a in ["WTI", "GLD", "USD"]:
        ax2.plot(roll["Date"], roll[f"Net_{a}"], lw=0.8, ls=":", label=a)
    ax2.axhline(0, color="k", lw=0.7); ax2.legend(fontsize=8, ncol=5, loc="lower left")
    ax2.set_ylabel("Net spillover (%)"); ax2.set_title("(b) Net receivers; macro (dotted)", fontsize=10)
    ax2.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    plt.tight_layout(); plt.savefig(FIG + "Figure_6.png", dpi=300); plt.close()

    # Fig 5: TVP-VAR (6 primary)
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 6.5), sharex=True)
    for ax in (ax1, ax2): shade(ax)
    ax1.plot(tvp6["Date"], tvp6["TCI"], color="#542788", lw=1.1, label="TVP-VAR TCI (6 primary)")
    m13 = pd.merge(roll[["Date", "TCI"]], tvp6[["Date"]], on="Date")
    ax1.plot(m13["Date"], m13["TCI"], color="#08306b", lw=0.9, ls="--", alpha=0.7,
             label="Rolling DY TCI (13 assets)")
    ax1.legend(fontsize=8); ax1.set_ylabel("TCI (%)")
    ax1.set_title("(a) TVP-VAR vs rolling-window TCI", fontsize=10)
    for a, c in zip(["THNQ", "ROBT", "ICLN", "WTI", "GLD", "USD"],
                    ["#08519c", "#6baed6", "#cb181d", "#8073ac", "#238b45", "#636363"]):
        ax2.plot(tvp6["Date"], tvp6[f"Net_{a}"], lw=1.0, color=c, label=a)
    ax2.axhline(0, color="k", lw=0.7); ax2.legend(fontsize=8, ncol=6)
    ax2.set_ylabel("Net spillover (%)"); ax2.set_title("(b) TVP-VAR net directional spillovers", fontsize=10)
    ax2.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    plt.tight_layout(); plt.savefig(FIG + "Figure_7.png", dpi=300); plt.close()

    # Fig 6: QVAR
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12.5, 4.8))
    tcis = qvar["TCI_%"].values
    ax1.plot(range(5), tcis, "o-", color="#08306b", lw=1.5, ms=7)
    for i, v in enumerate(tcis):
        ax1.annotate(f"{v:.1f}%", (i, v), textcoords="offset points", xytext=(0, 9),
                     ha="center", fontsize=9)
    ax1.set_xticks(range(5))
    ax1.set_xticklabels(["Q05\nBear", "Q25", "Q50\nMedian", "Q75", "Q95\nBull"], fontsize=8)
    ax1.set_ylabel("TCI (%)"); ax1.set_title("(a) TCI across market states", fontsize=10)
    netmat = qvar[[f"Net_{a}_%" for a in assets]].values
    im = ax2.imshow(netmat, cmap="RdBu_r", vmin=-65, vmax=65, aspect="auto")
    ax2.set_xticks(range(13)); ax2.set_xticklabels(assets, rotation=45, ha="right", fontsize=8)
    ax2.set_yticks(range(5)); ax2.set_yticklabels(["Q05", "Q25", "Q50", "Q75", "Q95"], fontsize=8)
    for i in range(5):
        for j in range(13):
            ax2.text(j, i, f"{netmat[i,j]:.0f}", ha="center", va="center", fontsize=6.5,
                     color="white" if abs(netmat[i, j]) > 40 else "black")
    fig.colorbar(im, ax=ax2, shrink=0.85, label="Net spillover (%)")
    ax2.set_title("(b) Net spillover by market state", fontsize=10)
    plt.tight_layout(); plt.savefig(FIG + "Figure_8.png", dpi=300); plt.close()

    # Fig 7: GARCH vols (6 primary)
    prim = ["THNQ", "ROBT", "ICLN", "WTI", "GLD", "USD"]
    gc = {"THNQ": "#08519c", "ROBT": "#238b45", "ICLN": "#cb181d",
          "WTI": "#8073ac", "GLD": "#b2182b", "USD": "#01665e"}
    fig, axes = plt.subplots(3, 2, figsize=(12, 8), sharex=True)
    for ax, a in zip(axes.flat, prim):
        shade(ax)
        ax.plot(vols.index, vols[f"GARCH_{a}"], color=gc[a], lw=0.7)
        ax.fill_between(vols.index, vols[f"GARCH_{a}"], color=gc[a], alpha=0.15)
        ax.set_title(a, fontsize=9, color=gc[a]); ax.set_ylabel("σ (%)", fontsize=8)
    axes.flat[-1].xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
    fig.suptitle("GARCH(1,1) conditional volatilities — primary assets", fontsize=11)
    plt.tight_layout(); plt.savefig(FIG + "Figure_3.png", dpi=300); plt.close()

    # Fig 8: forecast evaluation
    perf = pd.read_csv("../results/table_forecast_performance.csv")
    def r2_of(model, tgt):
        return perf[(perf.Model == model) & (perf.Target == tgt)]["R2_oos"].iloc[0]
    fig, axes = plt.subplots(3, 1, figsize=(12, 9), sharex=True)
    for ax, t_ in zip(axes, ["TCI", "Net_THNQ", "Net_ICLN"]):
        ax.plot(fc["Date"], fc[f"actual_{t_}"], color="k", lw=1.2, label="Actual")
        ax.plot(fc["Date"], fc[f"persist_{t_}"], color="#2166ac", lw=0.9, ls="--",
                label=f"Persistence (R²={r2_of('Persistence', t_):.2f})")
        ax.plot(fc["Date"], fc[f"lstm_{t_}"], color="#b2182b", lw=0.8, alpha=0.8,
                label=f"LSTM (R²={r2_of('LSTM', t_):.2f})")
        ax.plot(fc["Date"], fc[f"lstmkan_{t_}"], color="#1b7837", lw=0.8, alpha=0.8,
                label=f"LSTM-KAN (R²={r2_of('LSTM-KAN', t_):.2f})")
        ax.legend(fontsize=8, ncol=2); ax.set_ylabel(t_)
    axes[0].set_title("One-step-ahead forecasts on test set: persistence dominates", fontsize=10)
    axes[-1].xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m"))
    plt.tight_layout(); plt.savefig(FIG + "Figure_9.png", dpi=300); plt.close()

    print("All figures saved to", FIG)

if __name__ == "__main__":
    main()
