"""
04_qvar_garch.py — Quantile VAR tail connectedness (Ando et al. 2022) and
GARCH(1,1) conditional volatilities (MLE, normal innovations).

Outputs:
  qvar_tail_connectedness_13ETF.csv   — TCI(tau) and net spillovers at 5 quantiles
  garch11_conditional_volatilities.csv — 13 conditional-volatility series
  garch11_parameters.csv               — (mu, omega, alpha, beta, alpha+beta) per asset
"""
import warnings
warnings.filterwarnings("ignore")
import numpy as np
import pandas as pd
import statsmodels.api as sm
from scipy.optimize import minimize
from dy_core import gfevd, connectedness

QUANTILES = (0.05, 0.25, 0.50, 0.75, 0.95)
P, H = 2, 10

def qvar_connectedness(X, p=2):
    T, N = X.shape
    Y = X[p:]
    Xr = np.column_stack([np.ones(T - p)] + [X[p - k:T - k] for k in range(1, p + 1)])
    out = []
    for tau in QUANTILES:
        Phis = [np.zeros((N, N)) for _ in range(p)]
        resids = np.zeros((T - p, N))
        for i in range(N):
            mod = sm.QuantReg(Y[:, i], Xr).fit(q=tau, max_iter=3000)
            resids[:, i] = mod.resid
            for k in range(p):
                Phis[k][i, :] = mod.params[1 + k * N: 1 + (k + 1) * N]
        Sig = np.cov(resids.T)
        th = gfevd(Phis, Sig, H=H)
        tci_q, _, _, net_q = connectedness(th)
        row = {"quantile": tau, "TCI_%": round(tci_q, 2)}
        for j, a in enumerate(ASSETS):
            row[f"Net_{a}_%"] = round(net_q[j], 2)
        out.append(row)
        print(f"tau={tau:.2f}: TCI={tci_q:.2f}%")
    return pd.DataFrame(out)

def garch11(r):
    r = np.asarray(r, float); T = len(r); mu = r.mean(); e = r - mu
    def nll(par):
        w, a, b = par
        if w <= 0 or a < 0 or b < 0 or a + b >= 0.9999: return 1e10
        s2 = np.empty(T); s2[0] = e.var()
        for t in range(1, T):
            s2[t] = w + a * e[t-1] ** 2 + b * s2[t-1]
        if np.any(s2 <= 0): return 1e10
        return 0.5 * np.sum(np.log(2 * np.pi * s2) + e ** 2 / s2)
    res = minimize(nll, [e.var() * 0.05, 0.08, 0.88], method="Nelder-Mead",
                   options={"maxiter": 5000, "xatol": 1e-8, "fatol": 1e-8})
    w, a, b = res.x
    s2 = np.empty(T); s2[0] = e.var()
    for t in range(1, T):
        s2[t] = w + a * e[t-1] ** 2 + b * s2[t-1]
    return np.sqrt(s2), (mu, w, a, b, a + b)

def main():
    global ASSETS
    r = pd.read_csv("../results/returns_cleaned.csv", parse_dates=["Date"]).set_index("Date")
    ASSETS = r.columns.tolist()

    print("QVAR (5 quantiles x 13 equations)...")
    qvar_connectedness(r.values, p=P).to_csv("../results/qvar_tail_connectedness_13ETF.csv", index=False)

    vols = pd.DataFrame(index=r.index); pars = {}
    for a in ASSETS:
        v, par = garch11(r[a].values)
        vols[f"GARCH_{a}"] = v; pars[a] = par
    vols.to_csv("../results/garch11_conditional_volatilities.csv")
    pd.DataFrame(pars, index=["mu", "omega", "alpha", "beta", "persistence"]).T.round(5)\
        .to_csv("../results/garch11_parameters.csv")
    print("GARCH(1,1) done.")

if __name__ == "__main__":
    main()
