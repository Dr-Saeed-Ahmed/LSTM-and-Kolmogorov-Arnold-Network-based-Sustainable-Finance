"""
02_static_rolling_dy.py — Static and rolling-window Diebold–Yilmaz connectedness
for the 13-asset sustainability-finance network (cleaned data).
Settings: VAR p=2 (BIC-selected), H=10, rolling window W=200 trading days.
Outputs: corrected_static_FEVD_matrix_13ETF.csv, corrected_static_net_spillovers_13ETF.csv,
         corrected_rollingDY_results_13ETF.csv
"""
import numpy as np
import pandas as pd
from dy_core import estimate_var, gfevd, connectedness, var_bic

P, H, W = 2, 10, 200

def main():
    r = pd.read_csv("../results/returns_cleaned.csv", parse_dates=["Date"]).set_index("Date")
    assets = r.columns.tolist()
    X = r.values
    N = len(assets)

    print("BIC lag-order selection:")
    for p in [1, 2, 3, 4]:
        print(f"  p={p}: BIC={var_bic(X, p):.0f}")

    # ---- static ----
    Phi, Sig = estimate_var(X, p=P)
    th = gfevd(Phi, Sig, H=H)
    tci, to, frm, net = connectedness(th)
    pd.DataFrame(th, index=assets, columns=assets).round(2).to_csv(
        "../results/corrected_static_FEVD_matrix_13ETF.csv")
    tbl = pd.DataFrame({"TO_others_%": to.round(2), "FROM_others_%": frm.round(2),
                        "NET_%": net.round(2), "Own_share_%": np.diag(th).round(2)},
                       index=assets).sort_values("NET_%", ascending=False)
    tbl.to_csv("../results/corrected_static_net_spillovers_13ETF.csv")
    print(f"\nStatic TCI = {tci:.2f}%")
    print(tbl)

    # ---- rolling ----
    rows = []
    for t in range(W, len(X)):
        Phi_t, Sig_t = estimate_var(X[t - W:t], p=P)
        th_t = gfevd(Phi_t, Sig_t, H=H)
        tci_t, _, _, net_t = connectedness(th_t)
        rows.append([tci_t] + list(net_t))
    roll = pd.DataFrame(rows, columns=["TCI"] + [f"Net_{a}" for a in assets])
    roll.insert(0, "Date", r.index[W:].values)
    roll.round(4).to_csv("../results/corrected_rollingDY_results_13ETF.csv", index=False)
    print(f"\nRolling TCI: mean={roll['TCI'].mean():.2f}%, "
          f"range {roll['TCI'].min():.1f}-{roll['TCI'].max():.1f}%")

if __name__ == "__main__":
    main()
