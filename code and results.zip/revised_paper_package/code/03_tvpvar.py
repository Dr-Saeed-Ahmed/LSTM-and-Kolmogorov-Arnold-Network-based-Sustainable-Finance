"""
03_tvpvar.py — TVP-VAR connectedness (Kalman filter with forgetting factors,
Koop–Korobilis style; Antonakakis–Chatziantoniou–Gabauer application).

IMPORTANT (documented in the paper): with N=13 assets and p=2, the forgetting-factor
filter adapts 351 coefficients per time step with an effective memory of ~100 obs,
which is under-determined and produces explosive net-spillover estimates for
near-zero-variance assets (|net| up to ~900%). We therefore:
  (i) report the 13-asset forgetting-factor run + lambda/kappa sensitivity table as a
      documented stability exercise (tvpvar_results_13ETF.csv, tvpvar_lambda_sensitivity.csv);
 (ii) use the 6-primary-asset TVP-VAR (78 coefficients) as the stable, reported
      dynamic estimator (tvpvar_results_6primary.csv).
"""
import numpy as np
import pandas as pd
from dy_core import estimate_var, gfevd, connectedness

PRIMARY = ["THNQ", "ROBT", "ICLN", "WTI", "GLD", "USD"]

def tvpvar_connectedness(X, p=2, lam=0.99, kap=0.99, W0=200, H=10):
    """Kalman-filter TVP-VAR with forgetting factors. OLS init on first W0 obs."""
    T, N = X.shape
    m = 1 + p * N
    s = N * m
    # init
    Y0 = X[p:W0]
    Xr = np.column_stack([np.ones(W0 - p)] + [X[p - k:W0 - k] for k in range(1, p + 1)])
    B0, *_ = np.linalg.lstsq(Xr, Y0, rcond=None)
    E0 = Y0 - Xr @ B0
    Sig = (E0.T @ E0) / (W0 - p - m)
    XtXinv = np.linalg.inv(Xr.T @ Xr)
    beta = B0.T.reshape(-1)                      # equation-major vec
    P = np.kron(np.diag(np.diag(Sig)), XtXinv)   # OLS covariance of coefficients
    I_N = np.eye(N)
    out_tci, out_net, tidx = [], [], []
    for t in range(W0, T):
        z = np.concatenate([[1.0]] + [X[t - k] for k in range(1, p + 1)])
        Zt = np.kron(z, I_N)
        P = P / lam                              # forgetting factor (coefficients)
        e = X[t] - Zt @ beta                     # one-step-ahead forecast error
        Sig = kap * Sig + (1 - kap) * np.outer(e, e)   # EWMA covariance
        K = P @ Zt.T @ np.linalg.inv(Zt @ P @ Zt.T + Sig)
        beta = beta + K @ e
        P = P - K @ Zt @ P
        Phis = []
        for k in range(p):
            blk = np.zeros((N, N))
            for i in range(N):
                blk[i] = beta[i * m + 1 + k * N: i * m + 1 + (k + 1) * N]
            Phis.append(blk)
        th = gfevd(Phis, Sig, H=H)
        tci_t, _, _, net_t = connectedness(th)
        out_tci.append(tci_t); out_net.append(net_t); tidx.append(t)
    return np.array(out_tci), np.array(out_net), tidx

def main():
    r = pd.read_csv("../results/returns_cleaned.csv", parse_dates=["Date"]).set_index("Date")
    assets = r.columns.tolist()

    # (i) 13-asset run (documented as unstable; stability exercise)
    t13, n13, i13 = tvpvar_connectedness(r.values, p=2, lam=0.99, kap=0.99)
    df13 = pd.DataFrame(n13, columns=[f"Net_{a}" for a in assets])
    df13.insert(0, "Date", r.index[i13]); df13.insert(1, "TCI", t13)
    df13.to_csv("../results/tvpvar_results_13ETF.csv", index=False)
    print(f"13-asset TVP-VAR (UNSTABLE, reported as robustness): "
          f"TCI mean={t13.mean():.1f}%, max|net|={np.abs(n13).max():.0f}%")

    # sensitivity table
    sens = []
    for lam, kap in [(0.96, 0.96), (0.99, 0.96), (0.99, 0.99), (1.0, 1.0)]:
        t_, _, _ = tvpvar_connectedness(r.values, p=2, lam=lam, kap=kap)
        sens.append({"lambda": lam, "kappa": kap, "TCI_mean_%": round(t_.mean(), 2),
                     "TCI_min_%": round(t_.min(), 1), "TCI_max_%": round(t_.max(), 1)})
    pd.DataFrame(sens).to_csv("../results/tvpvar_lambda_sensitivity.csv", index=False)
    print(pd.DataFrame(sens))

    # (ii) 6-primary-asset run (stable, reported)
    t6, n6, i6 = tvpvar_connectedness(r[PRIMARY].values, p=2, lam=0.99, kap=0.99)
    df6 = pd.DataFrame(n6, columns=[f"Net_{a}" for a in PRIMARY])
    df6.insert(0, "Date", r.index[i6]); df6.insert(1, "TCI", t6)
    df6.to_csv("../results/tvpvar_results_6primary.csv", index=False)
    print(f"\n6-asset TVP-VAR (reported): TCI mean={t6.mean():.2f}%, "
          f"range {t6.min():.1f}-{t6.max():.1f}%, max|net|={np.abs(n6).max():.0f}%")

if __name__ == "__main__":
    main()
